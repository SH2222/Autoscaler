set :port, 6006
set :bind, "0.0.0.0"
config[:ws_config] = 'dashboard.json'
