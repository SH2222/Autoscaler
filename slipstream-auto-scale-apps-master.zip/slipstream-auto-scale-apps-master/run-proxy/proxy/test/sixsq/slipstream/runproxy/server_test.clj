(ns sixsq.slipstream.runproxy.server-test
  (:require [clojure.test :refer :all]
            [sixsq.slipstream.runproxy.server :refer :all]))

(deftest a-test
  (testing "FIXME, I pass."
    (is (= 0 0))))
